"""One native Ascend rank. Imported by spawn without importing torch in the parent."""

from __future__ import annotations

import json
import os
import sys
import time
import traceback
from contextlib import nullcontext
from pathlib import Path
from typing import Any

from .config import digest, native_environment
from .io_utils import write_json, write_jsonl
from .planner import steps


class NativePathMismatch(RuntimeError):
    """The pinned model or repeated native metadata/module path did not match."""


def entry(cfg: dict, case: dict, mapping: dict, model_dir: str, init_method: str, output: str) -> None:
    directory = Path(output) / f"rank_{mapping['global_rank']}"
    directory.mkdir(parents=True, exist_ok=True)
    with (directory / "worker.log").open("a", encoding="utf-8", buffering=1) as log:
        os.dup2(log.fileno(), 1)
        os.dup2(log.fileno(), 2)
        sys.stdout = log
        sys.stderr = log
        try:
            os.environ.update(native_environment(cfg))
            visible = ",".join(map(str, mapping["visible_devices"]))
            os.environ.update(CUDA_VISIBLE_DEVICES=visible, ASCEND_RT_VISIBLE_DEVICES=visible)
            _run(cfg, case, mapping, model_dir, init_method, directory)
        except BaseException as error:
            traceback.print_exc()
            write_json(
                directory / "error.json",
                {
                    "rank": mapping["global_rank"],
                    "type": type(error).__name__,
                    "error": str(error),
                    "traceback": traceback.format_exc(),
                    "status": (
                        "PATH_MISMATCH"
                        if isinstance(error, NativePathMismatch)
                        else "OOM"
                        if "out of memory" in str(error).lower() or "OutOfMemory" in type(error).__name__
                        else "FAILED"
                    ),
                },
            )
            log.flush()
            raise SystemExit(1) from error


def _run(cfg: dict, case: dict, mapping: dict, model_dir: str, init_method: str, directory: Path) -> None:
    # This is intentionally the first accelerator/native import in the spawned rank.
    from deepinfer import PLATFORM

    if not PLATFORM.is_npu:
        raise RuntimeError("Ascend platform was not selected")
    import torch
    import torch.distributed as dist

    from deepinfer.engine.arg_utils import EngineArgs
    from deepinfer.engine.engine_type import EngineType
    from deepinfer.model_executor import eplb
    from deepinfer.worker.base import WorkerBase, set_pdeathsig
    from deepinfer.worker.cache_engine import CacheEngine

    from .alignment import NativeDiagnostic
    from .profiler import create_profiler, save_profile_index
    from .workload import NativeSequences, StateSnapshot, seed_cache

    class BenchWorker(WorkerBase):
        def start_slave_worker_loop(self) -> None:
            # All eight ranks execute the same benchmark loop. Native follower
            # metadata broadcasts remain in ModelRunner._prepare_input_follower.
            set_pdeathsig()

    set_pdeathsig()
    batch = case["per_dp_batch_size"]
    capacity = max(batch * (cfg["runtime"]["mtp_draft_length"] + 1), case["cp"] * case["max_rows_per_rank"])
    args = EngineArgs(
        model=model_dir,
        tokenizer=model_dir,
        engine_type=EngineType.PROMPT,
        load_format="dummy" if cfg["runtime"]["weights"] == "dummy" else "auto",
        seed=cfg["runtime"]["seed"],
        max_model_len=cfg["runtime"]["max_model_len"],
        data_parallel_size=case["dp"],
        context_parallel_size=case["cp"],
        expert_parallel_size=8,
        engram_parallel_size=8,
        engine_rank=mapping["dp_rank"],
        engine_group_rank=0,
        max_num_seqs=batch,
        max_num_batched_tokens=capacity,
        chunked_prefill=True,
        gpu_memory_utilization=cfg["runtime"]["gpu_memory_utilization"],
        tokens_per_block=128,
    )
    model_cfg, cache_cfg, parallel_cfg, scheduler_cfg = args.create_engine_configs()
    worker = BenchWorker(
        EngineType.PROMPT,
        model_cfg,
        parallel_cfg,
        scheduler_cfg,
        cache_cfg,
        mapping["cp_rank"],
        mapping["cp_rank"],
        init_method,
        mapping["cp_rank"] == 0,
    )
    worker.load_model()
    runner = worker.model_runner
    model = runner.model
    layers = model.model.layers
    if type(model).__name__ != "DeepseekVLForCausalLM" or len(layers) != 40 or not model.engram_enabled or not model.hc_enabled:
        raise NativePathMismatch("Loaded model does not match the full native V4.1 Flash graph contract")
    branches = []
    for i, layer in enumerate(layers):
        mlp = layer.mlp
        if not mlp.use_mega_moe or mlp.mma_type != "fp8xfp4":
            raise NativePathMismatch(f"Layer {i}: required Ascend FP8xFP4 MegaMoE path unavailable")
        branches.append(
            {
                "layer": i,
                "use_mega_moe": mlp.use_mega_moe,
                "mma_type": mlp.mma_type,
                "physical_experts": mlp.num_physical_experts,
                "local_experts": mlp.num_local_physical_experts,
            }
        )
    cache = CacheEngine(cache_cfg, model.cfg, batch, num_gpu_blocks=case["logical_cache_blocks"])
    worker.cache_engine, worker.gpu_cache = cache, cache.gpu_cache
    with torch.inference_mode():
        seeded = seed_cache(cache, case, cfg["runtime"]["seed"], mapping["dp_rank"] * batch)
        snapshot = StateSnapshot(cache)
    write_json(
        directory / "native_contract.json",
        {
            "rank_mapping": mapping,
            "model_class": type(model).__name__,
            "branches": branches,
            "cache": seeded,
            "max_num_batched_tokens": capacity,
            "runtime_max_model_len": model_cfg.runtime_max_model_len,
            "model_cfg": json.loads(json.dumps(model_cfg.model_cfg, default=str)),
            "environment": native_environment(cfg),
        },
    )
    sequences = NativeSequences(case, cfg["runtime"]["seed"], mapping["dp_rank"] * batch) if mapping["cp_rank"] == 0 else None
    trajectory = list(steps(case))
    start, end = torch.npu.Event(enable_timing=True), torch.npu.Event(enable_timing=True)
    measure_enabled = False
    profiling_enabled = False
    forward_scope = None
    hook_calls = [0, 0]

    def before(*_: Any) -> None:
        nonlocal forward_scope
        if profiling_enabled:
            forward_scope = torch.profiler.record_function("prefill950:native_model_forward")
            forward_scope.__enter__()
        if measure_enabled:
            hook_calls[0] += 1
            start.record()

    def after(*_: Any) -> None:
        if measure_enabled:
            end.record()
            hook_calls[1] += 1
        if profiling_enabled:
            forward_scope.__exit__(None, None, None)

    handles = [model.register_forward_pre_hook(before), model.register_forward_hook(after)]
    minimum_free = torch.npu.mem_get_info()[0]

    @torch.inference_mode()
    def run_trajectory(measured: bool = False, round_index: int = 0, iteration: int = 0) -> list[dict]:
        nonlocal measure_enabled, minimum_free
        measure_enabled = measured
        with torch.profiler.record_function("prefill950:cache_restore") if profiling_enabled else nullcontext():
            snapshot.restore()
            torch.npu.synchronize()
        records = []
        for step in trajectory:
            # Construct a new native SequenceMetadata and InputMetadata per call.
            begin = time.perf_counter()
            metadata = sequences.metadata(step) if sequences is not None else None
            dist.barrier()  # CPU/Gloo coordination, outside both NPU event boundaries.
            hook_calls[:] = [0, 0]
            with (
                torch.profiler.record_function(f"prefill950:case={case['case_id']}:iteration={iteration}:chunk={step['chunk']}")
                if profiling_enabled
                else nullcontext()
            ):
                output = runner.execute_main_model(metadata, cache.gpu_cache)
            if measured:
                if hook_calls != [1, 1]:
                    raise RuntimeError(f"Expected one full root forward, observed hooks {hook_calls}")
                end.synchronize()  # Never synchronize inside the native forbidden-sync region.
                records.append(
                    {
                        "round": round_index,
                        "iteration": iteration,
                        "chunk": step["chunk"],
                        "forward_ms": start.elapsed_time(end),
                        "host_preparation_and_forward_ms": (time.perf_counter() - begin) * 1000,
                    }
                )
            else:
                torch.npu.synchronize()
            del output, metadata
            minimum_free = min(minimum_free, torch.npu.mem_get_info()[0])
        measure_enabled = False
        return records

    graph = {"match": False, "kind": "NATIVE_METADATA_AND_MODULE_REPEATABILITY", "external_reference_validated": False}
    if cfg["alignment"]["enabled"]:
        signatures = []
        for i in range(2):
            with NativeDiagnostic(runner) as diagnostic:
                run_trajectory()
            sig = diagnostic.result()
            write_json(directory / f"graph_signature_{i}.json", sig)
            signatures.append(sig["sha256"])
        graph.update(match=signatures[0] == signatures[1], signatures=signatures, branch_sha256=digest(branches))
        if not graph["match"]:
            raise NativePathMismatch("Repeated fresh native metadata/module signatures differ; inspect graph_signature files")
    for _ in range(cfg["measurement"]["warmup"]):
        run_trajectory()
    preparation_memory = {
        "preparation_peak_torch_allocated_bytes": torch.npu.max_memory_allocated(),
        "preparation_peak_torch_reserved_bytes": torch.npu.max_memory_reserved(),
        "cache_block_bytes": seeded["block_bytes"],
        "cache_state_bytes": seeded["state_bytes"],
        "state_snapshot_bytes": snapshot.saved.numel(),
    }
    torch.npu.reset_peak_memory_stats()
    manager = eplb.current()
    if manager is None:
        raise RuntimeError("Native EPLB manager is missing")
    with torch.inference_mode():
        for i in range(manager.num_moe_layers):
            manager.layer(i).expert_count.zero_()
    samples = []
    for r in range(cfg["measurement"]["rounds"]):
        for k in range(cfg["measurement"]["iterations"]):
            samples.extend(run_trajectory(True, r, k))
        write_jsonl(directory / "samples.jsonl", samples)
    expert_assignments = sum(int(manager.layer(i).expert_count.sum().item()) for i in range(manager.num_moe_layers))
    memory = {
        "peak_torch_allocated_bytes": torch.npu.max_memory_allocated(),
        "peak_torch_reserved_bytes": torch.npu.max_memory_reserved(),
        "minimum_device_free_bytes": int(minimum_free),
        "memory_scope": "Torch peaks plus device-free samples after cache seeding and each forward; not continuous HBM peak",
        **preparation_memory,
    }
    profile = {"valid": False, "status": "DISABLED"}
    if cfg["profile"]["enabled"]:
        profiling_enabled = True
        profiler, profile_error = None, None
        try:
            profiler = create_profiler(directory / "profiler", cfg["profile"], mapping["global_rank"])
            profiler.start()
        except Exception as error:
            profile_error = f"{type(error).__name__}: {error}"
        # Keep all ranks on the same model collective trajectory, even if one
        # rank cannot start profiling. Timing samples above remain available.
        for pindex in range(sum(cfg["profile"][k] for k in ("wait_steps", "warmup_steps", "active_steps"))):
            run_trajectory(iteration=pindex)
            if profiler is not None and profile_error is None:
                try:
                    profiler.step()
                except Exception as error:
                    profile_error = f"{type(error).__name__}: {error}"
        if profiler is not None:
            try:
                profiler.stop()
            except Exception as error:
                profile_error = f"{type(error).__name__}: {error}"
        profiling_enabled = False
        profile = save_profile_index(directory / "profiler", cfg["profile"]["active_steps"] * len(trajectory))
        profile.update(status="FAILED" if profile_error or not profile["valid"] else "OK", error=profile_error)
        if profile_error:
            profile["valid"] = False
        write_json(directory / "profiler_index.json", profile)
    for handle in handles:
        handle.remove()
    write_json(
        directory / "outcome.json",
        {
            "rank": mapping["global_rank"],
            "samples": samples,
            "profile": profile,
            "graph_alignment": graph,
            "expert_assignments": expert_assignments,
            **memory,
        },
    )
    sys.stdout.flush()
    worker.stop()
